# clean java rebuild
